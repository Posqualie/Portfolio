function mouseOver(id)
{

x=document.getElementById(id)//get the picture element
x.src=id// change its source to the id

}

function mouseOut(id)
{

new_src=id.slice(0,-9)+'.jpg' //slice the id to get the image name without the price
x=document.getElementById(id)//get the picture element
x.src=new_src// change the picture src to the new source

}
function addproduct(price,product)
{
x=document.getElementById('order')// get the select element to add the products
output=document.getElementById('total')//get the total element to display total
option = document.createElement("option");
option.text = "$"+price+"-"+product;// formatiing the output
x.add(option);//adding the new option to the list of items
sum=0.0
for (var i = 0; i < x.length; i++)//iterating and adding the product prices
{
innerhtml=x[i].innerHTML
amount=parseFloat(innerhtml.slice(1,5))
sum=sum+amount
}
console.log(sum)
output.innerHTML="Total: $"+sum.toFixed(2)

}

function clear_order()
{
x=document.getElementById('order')//get the order element to clear
x.innerHTML = '';//make it null
output=document.getElementById('total')//get the total element to clear
output.innerHTML = '';//make it null
}
"use strict";
/* JavaScript 7th Edition Chapter 6 Project 06-01 */

// Declare variables
var submitButton = document.getElementById("submitButton");
var pwd = document.getElementById("pwd");
var pwd2 = document.getElementById("pwd2");

// Create event listener for submitButton click event
submitButton.addEventListener("click", function (event) {
   // Prevent the default form submission
   event.preventDefault();

   // Form validation
   if (!pwd.checkValidity()) {
      alert("Your password must be at least 8 characters with at least one letter and one number.");
   } else if (pwd.value !== pwd2.value) {
      alert("Your passwords must match.");
   } else {
      // Set validation message to an empty string (or handle accordingly)
      alert("Form submitted successfully!");
   }
});
